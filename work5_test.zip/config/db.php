<?php

$config = [
    'host' => 'localhost',
    'dbname' => 'test',
    'username' => 'root',
    'password' => '',
];

return $config;