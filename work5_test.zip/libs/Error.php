<?php
  
namespace libs;
 
class Error 
{
	public function __construct() 
	{
	}
}