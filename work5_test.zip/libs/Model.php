<?php
  
namespace libs;
 
class Model 
{
	public function __construct() 
	{

	}
}
