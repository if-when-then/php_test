<h3>Введите данные для входа</h3>
<div class="row">
    <div class="col-sm-6">
		<form action="auth" method="post">
			<div class="form-group">
				<label for="exampleInputEmail1">Имя пользователя</label>
				<input type="text" name="login" class="form-control" placeholder="Username" required autofocus><br>				
				<label for="exampleInputEmail1">Пароль для входа</label>			
				<input type="password" name="password" class="form-control" placeholder="Password" required><br>
			</div>					
			<button name="action" class="btn btn-lg btn-primary btn-block">Sign in</button>			
		</form>
   </div>
</div>
